# API List

[x] API Register + Send OTP
[x] API Check OTP
[x] Resend OTP
[x] API Finish Register
[x] Login

[x] Request Reset Password + Send OTP
[x] Resend OTP
[x] Check OTP
[x] Reset Password

[x] Get Profile
[x] Update Profile

[x] Migration & Model Slider
[x] Seeder Slider
[x] API Slider

[x] Migration & Model Category
[x] Seeder Category
[x] API Category

[x] Migration & Model Province, City, Address
[x] Import Database Dump for Province, City
[x] API CRUD Address
[x] API Set Address Utama

[x] Create credential google
[x] Create config google
[x] Create API

[x] Migration & Model: Product, Image, Variations, Review
[x] Dummy Files
[x] Seeder Product
[x] API Explore Product
[x] API Detail Product
[x] API Product Review
[x] API Detail Seller

[x] Migration & Model: Cart, CartItem
[x] Add to Cart
[x] List Cart
[x] Remove Item
[x] Update Cart Item

[x] Migration & Model: Voucher
[x] Voucher Seeder
[x] Get List Voucher
[x] Apply Voucher
[x] Remove Voucher

[x] Overview + RajaOngkir Config
[x] Set Address
[x] Get Shipping
[x] Update Shipping

[x] Overview Checkout
[x] Overview Midtrans
[x] API Checkout
[x] Callback Midtrans

[x] Install package Wallet
[x] Add dummy deposit
[x] Add balance on profile response
[x] API Toggle with Coin
[x] Cut balance on Checkout

[x] Send email to seller

[x] List Order
[x] Detail Order
[x] Mark as Done + Forward Saldo ke Seller
[x] Add Review + Add Koin Balance

## API Seller

[x] List Product
[x] Add Product
[x] Edit Product
[x] Delete Product

[x] List Voucher
[x] Add Voucher
[x] Edit Voucher
[x] Delete Voucher

[x] List Order (Only paid)
[x] Detail Order
[x] Add Status (paid -> on_processing, on_processing -> on_delivery, add on_delivery note)

[x] List Transaksi Wallet
[x] Get List Bank
[x] Withdraw
