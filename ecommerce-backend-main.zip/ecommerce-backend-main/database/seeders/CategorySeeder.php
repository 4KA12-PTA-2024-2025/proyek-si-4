<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Kesehatan',
                'icon' => 'category/Kesehatan.webp',
                'childs' => [
                    'Hand Sanitizer,'
                ],
            ],
            [
                'name' => 'Aksesoris Fashion',
                'icon' => 'category/Aksesoris-Fashion.webp',
                'childs' => [
                   'Ikat Pinggang', 'Dasi', 
                ],
            ],
            [
                'name' => 'Elektronik (Kelistrikan)',
                'icon' => 'category/Elektronik.webp',
                'childs' => [
                    'Microwave',
                ],
            ],
            [
                'name' => 'Pakaian Pria',
                'icon' => 'category/Fashion-Pria.webp',
                'childs' => [
                    'Kemeja', 'Jas','Celana Panjang Jeans', 'Hoodie & Sweatshirt',
                ],
            ],

            [
                'name' => 'Sepatu Pria',
                'icon' => 'category/Sepatu-Pria.webp',
                'childs' => [
                    'Sandal', 'Sneakers', 'Slip-On & Mules', 
                ],
            ],

            [
                'name' => 'Handphone & Aksesoris',
                'icon' => 'category/Handphone.webp',
                'childs' => [
                    'Handphone','Casing'
                ],
            ],


            [
                'name' => 'Fashion Muslim',
                'icon' => 'category/Fashion-Muslim.webp',
                'childs' => [
                  'Fashion Muslim',
                ],
            ],


            [
                'name' => 'Tas Wanita',
                'icon' => 'category/Tas-Wanita.webp',
                'childs' => [
                   'Ransel Wanita','Tas Wanita lainnya',
                ],
            ],


            [
                'name' => 'Pakaian Wanita',
                'icon' => 'category/Fashion-Wanita.webp',
                'childs' => [
                    'Dress', 'Jas',' Celana Panjang & Legging', 'Pakaian Wanita lainnya'
                ],
            ],

            [
                'name' => 'Sepatu Wanita',
                'icon' => 'category/Sepatu-Wanita.webp',
                'childs' => [
                    'Sepatu Flat', 'Sepatu Wanita lainnya,'
                ],
            ],

            [
                'name' => 'Tas Pria',
                'icon' => 'category/Tas-Pria.webp',
                'childs' => [
                    'Tas Kerja','Tas Pinggang Pria','Tas Pria lainnya',
                ],
            ],

            [
                'name' => 'Jam Tangan',
                'icon' => 'category/Jam-Tangan.webp',
                'childs' => [
                    'Jam Tangan Wanita', 'Jam Tangan Pria'
                ],
            ],

            [
                'name' => 'Makanan & Minuman',
                'icon' => 'category/Makanan-Minuman.webp',
                'childs' => [
                    'Biskuit', 'Makanan Ringan Kering lainnya'
                ],
            ],

            [
                'name' => 'Perawatan & Kecantikan',
                'icon' => 'category/Perawatan-dan-Kecantikan.webp',
                'childs' => [
                'Paket & Set Kecantikan', 'Perawatan & Kecantikan lainnya'
                ],
            ],

            [
                'name' => 'Ibu & Bayi',
                'icon' => 'category/Ibu-dan-Bayi.webp',
                'childs' => [
                    'Perlengkapan Ibu', 'Perlengkapan Bayi', 'Perlengkapan lainnya'
                ],
            ],


            [
                'name' => 'Fashion Bayi & Anak',
                'icon' => 'category/Fashion-Bayi-dan-Anak.webp',
                'childs' => [
                     'Pakaian Anak Laki-Laki', 'Pakaian Anak Perempuan'
                ],
            ],

            [
                'name' => 'Perlengkapan Rumah',
                'icon' => 'category/Perlengkapan-Rumah.webp',
                'childs' => [
                    'Perlengkapan Pesta', 'Perlengkapan Rumah lainnya'
                ],
            ],


            [
                'name' => 'Olahraga & Outdoor',
                'icon' => 'category/Olahraga-dan-Outdoor.webp',
                'childs' => [ 
                    'Olahraga & Outdoor lainnya', 'Sepeda', 'Bersepeda Lainnya'
                ],
            ],

            [
                'name' => 'Buku & Alat Tulis',
                'icon' => 'category/Buku-dan-Alat-Tulis.webp',
                'childs' => [
                   'Alat Tulis', 'Perlengkapan Sekolah & Kantor', 'Buku & Alat Tulis lainnya',
                ],
            ],

            [
                'name' => 'Hobi & Koleksi',
                'icon' => 'category/Hobi-dan-Koleksi.webp',
                'childs' => [
                    'Kipas Tangan', 'Souvenir & Hadiah lainnya',
                ],
            ],


            [
                'name' => 'Komputer & Laptop',
                'icon' => 'category/Komputer-Laptop.webp',
                'childs' => [
                    'Laptop','Komputer', 'Komponen Komputer & Laptop Lainnya',

                ],
            ],


            [
                'name' => 'Otomotif',
                'icon' => 'category/Otomotif.webp',
                'childs' => [
                     'Helm & Aksesoris Pengendara Motor', 'Aksesoris Sepeda Motor lainnya'

                ],
            ],
        ];

        foreach ($categories as $categoryPayload) {
            $category = \App\Models\Category::create([
                'slug' => \Str::slug($categoryPayload['name']),
                'name' => $categoryPayload['name'] ,     
                'icon' => $categoryPayload['icon'],
            ]);

            foreach ($categoryPayload['childs'] as $child) {
                $category->childs()->create([
                    'slug' => \Str::slug($child),
                    'name' => $child,
                ]);
            }
        }
    }
}
