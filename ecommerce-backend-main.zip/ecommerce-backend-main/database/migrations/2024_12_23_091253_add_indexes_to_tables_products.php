<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->index('slug');
            $table->index('category_id');
            $table->index(['price', 'price_sale']);
            $table->index('name');
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->index('slug');
            $table->index('parent_id');
        });

        Schema::table('users', function (Blueprint $table) {
            $table->index('username');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            Schema::table('products', function (Blueprint $table) {
                $table->dropIndex(['slug']);
                $table->dropIndex(['category_id']);
                $table->dropIndex(['price', 'price_sale']);
                $table->dropIndex(['name']);
            });

            Schema::table('categories', function (Blueprint $table) {
                $table->dropIndex(['slug']);
                $table->dropIndex(['parent_id']);
            });

            Schema::table('users', function (Blueprint $table) {
                $table->dropIndex(['username']);
            });
        });
    }
};
