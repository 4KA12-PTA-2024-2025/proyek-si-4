<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class ReviewOrder extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:review-order';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command untuk review order, jika belum bayar dan sudah expired, maka status ditambah expired.';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $orders = \App\Models\Order\Order::where('payment_expired_at', '<=', now())->get();

        foreach ($orders as $order) {
            $order->update([
                'payment_expired_at' => null
            ]);

            $order->status()->create([
                'status' => 'failed',
                'description' => 'Pembayaran melewati batas waktu'
            ]);
        }
    }
}
