<?php

namespace App\Http\Controllers;

use App\Models\ChatMessage;
use App\Models\User;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    public function index(User $user, Request $request)
    {
        $currentUser = auth()->user();

        return ChatMessage::query()
            ->where(function($query) use ($user, $currentUser){
                $query->where('sender_id', $currentUser->id)
                    ->where('receiver_id', $user->id);
            })
            ->orWhere(function($query) use ($user, $currentUser){
                $query->where('sender_id', $user->id)
                    ->where('receiver_id', $currentUser->id);
            })
            ->with(['sender', 'receiver'])
            ->orderBy('id', 'asc')
            ->get();
    }

    public function sendMessage(User $user, Request $request)
    {
        $request->validate([
            'message' => 'required|string'
        ]);

        $currentUser = auth()->user();

        $message = ChatMessage::create([
            'sender_id' => $currentUser->id,
            'receiver_id' => $user->id,
            'text' => $request->message
        ]);

        return $message;
    }
}
