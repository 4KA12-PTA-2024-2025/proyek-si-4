<?php

namespace App\Http\Controllers;

use App\Events\MessageEvent;
use App\Models\Chat;
use Illuminate\Http\Request;
use App\ResponseFormatter;

class UserMessageController extends Controller
{
    public function index()
    {
        $userId = auth()->user()->id;

        $chatUsers = Chat::with('receiverProfile')
            ->select(['receiver_id'])
            ->where('sender_id', $userId)
            ->where('receiver_id', '!=', $userId)
            ->groupBy('receiver_id')
            ->get();

        return ResponseFormatter::success($chatUsers, ['Chat users retrieved successfully']);
    }

    public function sendMessage(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'message' => 'required',
            'receiver_id' => 'required|exists:users,id'
        ]);

        if ($validator->fails()) {
            return ResponseFormatter::error(422, $validator->errors(), ['Validation error']);
        }

        $message = Chat::create([
            'sender_id' => auth()->user()->id,
            'receiver_id' => $request->receiver_id,
            'message' => $request->message,
            'seen' => false
        ]);

        broadcast(new MessageEvent($message->message, $message->receiver_id, $message->created_at));

        return ResponseFormatter::success($message, ['Message sent successfully']);
    }

    public function getMessages(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'receiver_id' => 'required|exists:users,id'
        ]);

        if ($validator->fails()) {
            return ResponseFormatter::error(422, $validator->errors(), ['Validation error']);
        }

        $senderId = auth()->user()->id;
        $receiverId = $request->receiver_id;

        $messages = Chat::whereIn('receiver_id', [$senderId, $receiverId])
            ->whereIn('sender_id', [$senderId, $receiverId])
            ->orderBy('created_at', 'asc')
            ->get();

        Chat::where(['sender_id' => $receiverId, 'receiver_id' => $senderId])->update(['seen' => true]);

        return ResponseFormatter::success($messages, ['Messages retrieved successfully']);
    }
}