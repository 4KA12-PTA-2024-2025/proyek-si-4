<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product\Product;
use App\Models\Slider;
use App\Models\User;
use App\ResponseFormatter;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function getSlider()
    {

        $sliders = cache()->remember('sliders', now()->addHours(1), function () {
            return Slider::all();
        });

        return ResponseFormatter::success($sliders->pluck('api_response'));
    }

    public function getCategory()
    {

        $categories = cache()->remember('categories', now()->addHours(1), function () {
            return Category::whereNull('parent_id')->with('childs')->get();
        });

        return ResponseFormatter::success($categories->pluck('api_response'));
    }

    public function getProduct()
    {
        $products = Product::query();


        $products->when(request()->category, function ($query, $categorySlug) {
            $category = Category::where('slug', $categorySlug)->firstOrFail();
            $query->where('category_id', $category->id);
        });

        $products->when(request()->seller, function ($query, $sellerUsername) {
            $seller = User::where('username', $sellerUsername)->firstOrFail();
            $query->where('seller_id', $seller->id);
        });

        $products->when(request()->search, function ($query, $search) {
            $query->where('name', 'LIKE', '%' . $search . '%');
        });

        $products->when(request()->minimum_price, function ($query, $minPrice) {
            $query->whereRaw('IF(price_sale > 0, price_sale, price) >= ?', [$minPrice]);
        });

        $products->when(request()->maximum_price, function ($query, $maxPrice) {
            $query->whereRaw('IF(price_sale > 0, price_sale, price) <= ?', [$maxPrice]);
        });


        if (!is_null(request()->sorting_price)) {
            $type = strtolower(request()->sorting_price) === 'asc' ? 'ASC' : 'DESC';
            $products->orderByRaw('IF(price_sale > 0, price_sale, price) ' . $type);
        } else {
            $products->latest('id');
        }

        $products->when(request()->categories && is_array(request()->categories), function ($query) {
            $query->whereHas('category', function ($subQuery) {
                $subQuery->whereIn('slug', request()->categories);
            });
        });

        $perPage = request()->per_page ?? 10;
        $products = $products->paginate($perPage);

        return ResponseFormatter::success($products->through(function ($product) {
            return $product->api_response_excerpt;
        }));
    }

    public function getProductDetail(string $slug)
    {

        $product = Product::with('category', 'seller')->where('slug', $slug)->firstOrFail();

        return ResponseFormatter::success($product->api_response);
    }

    public function getProductReview(string $slug)
    {
        $product = Product::where('slug', $slug)->with('reviews')->firstOrFail();
        $reviews = $product->reviews()->when(request()->rating, function ($query, $rating) {
            $query->where('star_seller', $rating);
        })->when(request()->with_attachment, function ($query) {
            $query->whereNotNull('attachments');
        })->when(request()->with_description, function ($query) {
            $query->whereNotNull('description');
        });

        $perPage = request()->per_page ?? 10;
        $reviews = $reviews->paginate($perPage);

        return ResponseFormatter::success($reviews->through(fn($review) => $review->api_response));
    }

    public function getSellerDetail(string $username)
    {
        // Cache untuk data seller jika jarang berubah
        $seller = cache()->remember("seller-detail-{$username}", now()->addMinutes(30), function () use ($username) {
            return User::where('username', $username)->firstOrFail();
        });

        return ResponseFormatter::success($seller->api_response_as_seller);
    }
}
