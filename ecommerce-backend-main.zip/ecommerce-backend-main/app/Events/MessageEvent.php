<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class MessageEvent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message;
    public $receiver_id;
    public $created_at;

    public function __construct($message, $receiver_id, $created_at)
    {
        $this->message = $message;
        $this->receiver_id = $receiver_id;
        $this->created_at = $created_at;
    }

    public function broadcastOn()
    {
        return new PrivateChannel('chat.' . $this->receiver_id);
    }

    public function broadcastWith()
    {
        return [
            'message' => $this->message,
            'receiver_id' => $this->receiver_id,
            'created_at' => $this->created_at,
        ];
    }
}