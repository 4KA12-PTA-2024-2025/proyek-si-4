<?php 

return [
    'amount' => 1000,
];