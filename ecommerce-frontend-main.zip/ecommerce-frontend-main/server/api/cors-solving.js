export default defineEventHandler(() => {
    return $fetch('https://upload.wikimedia.org/wikipedia/commons/4/45/NuxtJS_Logo.png')
});

