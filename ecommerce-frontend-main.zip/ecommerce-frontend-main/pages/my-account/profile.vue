<template>
    <NuxtPage/>
  </template>