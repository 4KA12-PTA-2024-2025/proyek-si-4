<template>
  <div class="text-sm text-black/80">
    <div class="bg-white">
      <UContainer
        v-if="statusSeller === 'pending'"
        as="section"
        class="py-5 flex gap-6 items-start"
      >
        <UCard>
          <div class="backdrop-seller py-5 flex gap-6 items-start">
            <USkeleton class="w-full h-6" />
            <USkeleton class="w-10/12 h-6" />
            <USkeleton class="w-8/12 h-6" />
            <USkeleton class="w-10/12 h-6" />
          </div>
        </UCard>
      </UContainer>
      <UContainer v-else as="section" class="py-5 flex gap-6 items-start">
        <div class="backdrop-seller">
          <UAvatar
            size="3xl"
            :alt="detailSeller.store_name"
            img-class="object-cover"
          />
          <span class="text-xl text-white font-medium">{{
            detailSeller.store_name
          }}</span>
        </div>
        <div class="grid grid-cols-2 py-4 gap-4 flex-1">
          <div class="flex gap-2 items-center">
            <IconShop />
            <span>Produk:</span>
            <span class="text-primary">{{ detailSeller.product_count }}</span>
          </div>
          <div class="flex gap-2 items-center">
            <UIcon name="i-heroicons:star" />
            <span>Penilaian:</span>
            <span class="text-primary">{{ detailSeller.rating_count }}</span>
          </div>
          <div class="flex gap-2 items-center">
            <IconUserCheck />
            <span>Bergabung:</span>
            <span class="text-primary">{{ detailSeller.join_date }}</span>
          </div>
        </div>
      </UContainer>
    </div>
    <UContainer class="py-8 space-y-8">
      <UCard>
        <p class="uppercase font-medium text-base">Tentang Toko</p>
        <div class="grid grid-cols-2 gap-4 mt-2">
          <BaseCarousel :items="items" aspect-ratio="16/9" />
          <div class="flex gap-6 justify-center flex-col">
            <p class="text-center">FAQ about Packing & Orders :</p>
            <p class="text-center">
              Order akan di proses di hari Senin-Sabtu | Jam 10:00 - 16:00. Jam
              di luar operasional akan di hitung besok. Orderan hari sabtu, yang
              melewati jam packing, akan di kirim hari Senin.
            </p>
          </div>
        </div>
      </UCard>
      <div v-if="status === 'loading'" class="text-center">Loading...</div>
      <div v-else-if="!data?.data?.data?.length" class="text-center">
        Tidak ada produk ditemukan.
      </div>
      <div v-else class="grid grid-cols-6 gap-5">
        <BaseProductCard
          v-for="prod in data?.data?.data"
          :key="`product-${prod.uuid}`"
          :title="prod.name"
          :price="prod.price_sale || prod.price"
          :image="prod.image_url"
          :sale="prod.sale_count"
          :slug="prod.slug"
          :discount="prod.price_discount_percentage"
        />
      </div>
      <div class="flex justify-center mt-8">
        <BasePagination
          v-model="page"
          :total="data?.data?.total"
          :page-size="data?.data?.per_page"
        />
      </div>
    </UContainer>
  </div>
</template>

<script setup>
import BgShop from "@/assets/images/bg-shop.png";
const background = ref(`url('${BgShop}')`);
const route = useRoute();

const page = ref(1);

const { data, status } = useApi(`/server/api/product`, {
  params: computed(() => ({
    seller: route.params.username,
    page: page.value,
  })),
});


const { data: detailSeller, status: statusSeller } = useApi(
  computed(() => `/server/api/seller/${route.params.username}`),
  {
    onResponse({ response }) {
      if (response.ok) {
        console.log("Data seller berhasil diambil:", response._data.data);
      }

      if (response.status === 404) {
        throw showError({
          statusCode: 404,
          message: "Produk tidak ditemukan",
        });
      }
    },
    transform(response) {
      return response?.data || {};
    },
  }
);

const items = [
  "https://picsum.photos/1920/1080?random=1",
  "https://picsum.photos/1920/1080?random=2",
  "https://picsum.photos/1920/1080?random=3",
  "https://picsum.photos/1920/1080?random=4",
  "https://picsum.photos/1920/1080?random=5",
  "https://picsum.photos/1920/1080?random=6",
];
</script>

<style scoped>
.backdrop-seller {
  @apply px-5 py-7 flex items-center gap-4 w-96 rounded;
  background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
    v-bind(background);
}
</style>
