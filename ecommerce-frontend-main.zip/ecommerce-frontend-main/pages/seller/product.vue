<template>
    <NuxtPage/>
</template>