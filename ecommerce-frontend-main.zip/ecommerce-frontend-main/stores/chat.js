import { defineStore } from 'pinia';
import { useSession } from '~/stores/session';
import { useApi } from '~/composables/use-api';
import { computed } from 'vue';

export const useChatStore = defineStore('chat', {
  state: () => ({
    users: [],
    messages: {},
    activeUser: null,
    newMessage: '',
  }),
  actions: {
    async fetchUsers() {
      const session = useSession();
      const { execute, data, error } = useApi('/server/api/users', {
        immediate: true,
      });

      try {
        await execute();
        if (data.value) {
          this.users = data.value.filter(user => user.id !== session.profile.id);
        } else if (error.value) {
          console.error('Error fetching users:', error.value);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    },
    async fetchMessages(userId) {
      const apiUrl = computed(() => `/server/api/messages/${userId}`);
      const { execute, data, error } = useApi(apiUrl, {
        immediate: false,
      });

      try {
        await execute();
        if (data.value) {
          this.messages[userId] = data.value;
          this.activeUser = userId;
        } else if (error.value) {
          console.error('Error fetching messages:', error.value);
        }
      } catch (error) {
        console.error('Error fetching messages:', error);
      }
    },
    async sendMessage(userId) {
      if (!this.newMessage.trim()) return;

      const apiUrl = computed(() => `/server/api/messages/${userId}`);
      const { execute, data, error } = useApi(apiUrl, {
        method: 'POST',
        body: { message: this.newMessage },
        immediate: false,
      });

      try {
        await execute();
        if (data.value) {
          this.messages[userId].push(data.value);
          this.newMessage = '';
        } else if (error.value) {
          console.error('Error sending message:', error.value);
        }
      } catch (error) {
        console.error('Error sending message:', error);
      }
    },
  },
});