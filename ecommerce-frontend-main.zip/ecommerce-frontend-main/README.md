# Nuxt Minimal Starter

Look at the [Nuxt documentation](https://nuxt.com/docs/getting-started/introduction) to learn more.


# Di bawah ini Adalah Dokumentasi Frontend Yang Akan Di Terapkan Dalam Project Ini


# E-Commerce Frontend Documentation


## Menerapkan Code Dari Desain To 

### Membuat Layout 
- [x] **Slicing Layout Utama -header**
- [x] **Slicing Layout Utama -footer** 
- [x] **Slicing Layout Secondary -header**
- [x] **Komponen -Slots**
- [x] **Slicing Layout Dashboard -header**
- [x] **Slicing Layout Dashboard -sidebar**

### Membuat Halaman Utama
- [x] **Slicing Homepage**
- [x] **Slicing Searchpage** 
- [x] **Product Detail**
- [x] **Slicing Cart**
- [x] **Slicing Checkout**
- [x] **Halaman Pembayaran**

### Membuat Halaman Authentikasi
- [x] **Slicing Login**
- [x] **Slicing Forgot Password** 
- [x] **Slicing Sign Up**



## Setup

Make sure to install dependencies:

```bash
# npm
npm install

# pnpm
pnpm install

# yarn
yarn install

# bun
bun install
```

## Development Server

Start the development server on `http://localhost:3000`:

```bash
# npm
npm run dev

# pnpm
pnpm dev

# yarn
yarn dev

# bun
bun run dev
```

## Production

Build the application for production:

```bash
# npm
npm run build

# pnpm
pnpm build

# yarn
yarn build

# bun
bun run build
```

Locally preview production build:

```bash
# npm
npm run preview

# pnpm
pnpm preview

# yarn
yarn preview

# bun
bun run preview
```

Check out the [deployment documentation](https://nuxt.com/docs/getting-started/deployment) for more information.
