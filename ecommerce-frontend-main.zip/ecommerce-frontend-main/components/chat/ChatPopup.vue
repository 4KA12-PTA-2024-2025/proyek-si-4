<template>
  <div>
    <div
      class="fixed bottom-2 right-5 bg-gradient-to-b from-primary to-[#2B6E8F] text-white px-5 py-2 rounded-full cursor-pointer flex items-center text-lg"
      @click="openModal"
    >
      <i class="mr-2"><IconChat /></i>Chat
    </div>
    <div
      v-if="showModal"
      class="fixed bottom-12 right-5 w-[800px] h-[700px] bg-white rounded-lg shadow-lg flex flex-col overflow-hidden"
    >
      <div
        class="bg-gradient-to-b from-primary to-[#2B6E8F] text-white p-3 flex justify-between items-center"
      >
        <h3>Chat</h3>
        <button class="text-white" @click="closeModal"><IconClose /></button>
      </div>

      <div class="flex flex-1">

        <div class="w-[35%] border-r border-gray-300 overflow-y-auto">
          <div
            v-for="user in chatStore.users"
            :key="user.id"
            :class="[
              'flex items-center p-2 cursor-pointer',
              user.id === chatStore.activeUser ? 'bg-gray-200' : '',
            ]"
            @click="selectUser(user.id)"
          >
            <div class="w-10 h-10 rounded-full overflow-hidden">
              <img
                :src="getUserPhotoUrl(user.photo)"
                alt="avatar"
                class="w-full h-full object-cover"
              />
            </div>
            <div class="ml-2">
              <p class="font-medium">{{ user.store_name }}</p>
            </div>
          </div>
        </div>
        <div class="w-[65%] flex flex-col justify-between">
          <div class="flex-1 p-3 overflow-y-auto">
            <div
              v-for="message in chatStore.messages[chatStore.activeUser] || []"
              :key="message.id"
              :class="[
                'mb-3 p-3 rounded-lg break-words',
                message.sender_id === session.profile.id 
                  ? 'self-end bg-teal-100 rounded-tr-none' 
                  : 'self-start bg-gray-200 rounded-tl-none',
              ]"
              :style="{
                maxWidth: '75%',
                alignSelf: message.sender_id === session.profile.id ? 'flex-end' : 'flex-start',
                backgroundColor: message.sender_id === session.profile.id ? '#81E6D9' : '#E2E8F0',
              }"
            >
              <p>{{ message.text }}</p>
            </div>  
          </div>
          <div class="flex p-3 border-t border-gray-300">
            <input
              v-model="chatStore.newMessage"
              type="text"
              placeholder="Kirim Pesan..."
              class="flex-1 p-2 border border-gray-300 rounded-md"
              @keyup.enter="sendMessage"
            />
            <button
              class="ml-2 px-5 py-2 bg-gradient-to-b from-primary to-[#2B6E8F] text-white rounded-md"
              @click="sendMessage"
            >
              <IconSend />
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue';
import { useChatStore } from '~/stores/chat';
import { useSession } from '~/stores/session';
import { useRuntimeConfig } from '#app';

export default {
  setup() {
    const chatStore = useChatStore();
    const session = useSession();
    const showModal = ref(false);
    const config = useRuntimeConfig();

    const openModal = () => {
      chatStore.fetchUsers(); 
      showModal.value = true;
    };

    const closeModal = () => {
      showModal.value = false;
    };

    const selectUser = (userId) => {
      if (userId) {
        chatStore.fetchMessages(userId);
      } else {
        console.error('User ID is undefined');
      }
    };

    const sendMessage = () => {
      if (chatStore.activeUser) {
        chatStore.sendMessage(chatStore.activeUser);
      } else {
        console.error('Active user is not selected');
      }
    };

    const getUserPhotoUrl = (photoPath) => {
      const baseUrl = config.public.baseUrl; 
      return `${baseUrl}/storage/${photoPath}`;
    };

    return {
      chatStore,
      session,
      showModal,
      openModal,
      closeModal,
      selectUser,
      sendMessage,
      getUserPhotoUrl,
    };
  },
};
</script>