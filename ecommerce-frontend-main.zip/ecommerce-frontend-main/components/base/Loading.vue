<template>
  <div class="flex gap-2 justify-center py-6">
    <IconLoading class="w-6 text-primary" />
    <p>Loading...</p>
  </div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
