<template>
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
    >
      <g clip-path="url(#clip0_4_4268)">
        <path
          d="M0.666016 0.666016H3.59935L6.93268 14.666H16.5327L19.3327 4.66602H4.93268"
          stroke="#2B888F"
          stroke-width="1.33333"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M7.99935 19.3327C8.73573 19.3327 9.33268 18.7357 9.33268 17.9993C9.33268 17.263 8.73573 16.666 7.99935 16.666C7.26297 16.666 6.66602 17.263 6.66602 17.9993C6.66602 18.7357 7.26297 19.3327 7.99935 19.3327Z"
          fill="#2B888F"
        />
        <path
          d="M15.3333 19.3327C16.0697 19.3327 16.6667 18.7357 16.6667 17.9993C16.6667 17.263 16.0697 16.666 15.3333 16.666C14.597 16.666 14 17.263 14 17.9993C14 18.7357 14.597 19.3327 15.3333 19.3327Z"
          fill="#2B888F"
        />
        <path
          d="M10 9.33203H14"
          stroke="#2B888F"
          stroke-width="1.33333"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
        <path
          d="M12 11.332V7.33203"
          stroke="#2B888F"
          stroke-width="1.33333"
          stroke-miterlimit="10"
          stroke-linecap="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_4_4268">
          <rect width="20" height="20" fill="white" />
        </clipPath>
      </defs>
    </svg>
  </template>
  
  <script setup></script>
  
  <style lang="scss" scoped></style>
  