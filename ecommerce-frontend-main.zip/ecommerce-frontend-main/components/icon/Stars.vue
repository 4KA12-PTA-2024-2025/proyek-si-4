<template>
    <svg
      width="30"
      height="30"
      viewBox="0 0 30 30"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M15 3L18.9375 11.1562L27.6562 12.1875L20.8125 17.8125L22.7812 27L15 22.3125L7.21875 27L9.1875 17.8125L2.34375 12.1875L11.0625 11.1562L15 3Z"
        stroke="currentColor"
        stroke-width="2.8125"
        stroke-miterlimit="10"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </template>
  
  <script setup></script>
  
  <style lang="scss" scoped></style>
  