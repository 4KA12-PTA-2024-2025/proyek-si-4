<template>
    <svg
      width="31"
      height="30"
      viewBox="0 0 31 30"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M2.625 26.25V18H10.6875L11.7187 20.1562H19.3125L20.3437 18L28.875 17.9062V26.25H2.625Z"
        stroke="currentColor"
        stroke-width="2.8125"
        stroke-miterlimit="10"
        stroke-linejoin="round"
      />
      <path
        d="M20.4375 7.5H26.0625L28.875 17.9062"
        stroke="currentColor"
        stroke-width="2.8125"
        stroke-miterlimit="10"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M2.625 18L5.4375 7.5H11.0625"
        stroke="currentColor"
        stroke-width="2.8125"
        stroke-miterlimit="10"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M15.75 3.75V13.125"
        stroke="currentColor"
        stroke-width="2.8125"
        stroke-miterlimit="10"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M19.5926 12.5625L16.2176 15.9375C15.9364 16.2187 15.5614 16.2187 15.3739 15.9375L11.9989 12.5625C11.6239 12.1875 11.9051 11.5312 12.4676 11.5312H19.2176C19.6864 11.5312 19.9676 12.1875 19.5926 12.5625Z"
        fill="currentColor"
      />
    </svg>
  </template>
  
  <script setup></script>
  
  <style lang="scss" scoped></style>
  