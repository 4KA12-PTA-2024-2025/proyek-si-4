<template>
  <svg
    width="15"
    height="16"
    viewBox="0 0 15 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M6.8 9.00039C8.89868 9.00039 10.6 7.29907 10.6 5.20039C10.6 3.10171 8.89868 1.40039 6.8 1.40039C4.70132 1.40039 3 3.10171 3 5.20039C3 7.29907 4.70132 9.00039 6.8 9.00039Z"
      stroke="black"
      stroke-miterlimit="10"
    />
    <path
      d="M9.19922 13.5L11.1992 15.5L14.1992 12"
      stroke="black"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M0.800781 15C0.800781 11.7 3.50078 9 6.80078 9C8.90078 9 10.7008 10 11.8008 11.6"
      stroke="black"
      stroke-miterlimit="10"
      stroke-linecap="round"
    />
  </svg>
</template>
