<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>

  <UNotifications />
</template>
<script setup>
const url = useRequestURL()
useSeoMeta({
  description: "Marketplace Islami dengan Semangat Kolaborasi dan Inovasi",
  ogTitle: "Al-Fatta - Ayo Belanja di sini",
  ogDescription: "Marketplace Islami dengan Semangat Kolaborasi dan Inovasi",
  twitterTitle: "Al-Fatta - Ayo Belanja di sini",
  ogUrl: () => url.href,
  ogImage: '/images/al-fatta.png',
  twitterImage: '/images/al-fatta.png',
  twitterDescription: "Marketplace Islami dengan Semangat Kolaborasi dan Inovasi",
  twitterCard: "summary",
});

useHead({
  titleTemplate: (titlePerPage) => {
        return titlePerPage ? `${titlePerPage} | Al-Fatta` : 'Al-Fatta - Ayo Belanja di sini'
  },
  htmlAttrs: {
    lang: "id",
  },
  link: [
    {
      rel: "icon",
      type: "image/png",
      href: "/favicon.png",
    },
  ],
});
</script>
<style>
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type="number"] {
  -moz-appearance: textfield;
}

.custom-shadow {
  box-shadow: 0px 6px 6px 0px #0000000f;
}
</style>
